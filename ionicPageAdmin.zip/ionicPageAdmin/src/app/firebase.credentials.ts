export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyDDMaWdaOeRjIuMTWlSoVecjuDb-BpkCRQ",
  authDomain: "ionicproject-77d74.firebaseapp.com",
  databaseURL: "https://ionicproject-77d74.firebaseio.com",
  projectId: "ionicproject-77d74",
  storageBucket: "ionicproject-77d74.appspot.com",
  messagingSenderId: "201770387592"
}